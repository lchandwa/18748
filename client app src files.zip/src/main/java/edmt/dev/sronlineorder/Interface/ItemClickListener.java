package edmt.dev.sronlineorder.Interface;

import android.view.View;

public interface ItemClickListener {

    void onClick(View v, int position, boolean isLongClick);
}
