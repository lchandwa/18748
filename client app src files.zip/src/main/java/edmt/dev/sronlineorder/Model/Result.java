package edmt.dev.sronlineorder.Model;

public class Result {
    public String message_id;
}
