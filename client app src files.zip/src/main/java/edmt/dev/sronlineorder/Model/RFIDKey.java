package edmt.dev.sronlineorder.Model;

public class RFIDKey {
    private String Key;
    private String State;

    public RFIDKey() {
    }

    public RFIDKey(String key, String state) {
        Key = key;
        State = state;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }

    public String getState() {
        return State;
    }

    public void setState(String state) {
        State = state;
    }
}
