package edmt.dev.sronlineorder;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.craftman.cardform.CardForm;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import edmt.dev.sronlineorder.Common.Common;
import edmt.dev.sronlineorder.Database.Database;
import edmt.dev.sronlineorder.Model.MyResponse;
import edmt.dev.sronlineorder.Model.Notification;
import edmt.dev.sronlineorder.Model.Order;
import edmt.dev.sronlineorder.Model.Request;
import edmt.dev.sronlineorder.Model.Sender;
import edmt.dev.sronlineorder.Model.Token;
import edmt.dev.sronlineorder.Model.User;
import edmt.dev.sronlineorder.Remote.APIService;
import edmt.dev.sronlineorder.ViewHolder.CartAdapter;
import info.hoang8f.widget.FButton;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Cart extends AppCompatActivity {

    private static final int result = 1;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    FirebaseDatabase database;
    DatabaseReference requests;

    FirebaseDatabase datab;
    DatabaseReference rfidList;

    TextView txtTotalPrice;
    FButton btnPlace;

    List<Order> cart = new ArrayList<>();

    CartAdapter adapter;

    APIService mService;

    String tableno, comment, rfidUser;
    String rfidValue = "";
    String formatAmount;
    double amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        mService = Common.getFCMService();

        //Launch firebase
        database = FirebaseDatabase.getInstance();
        requests = database.getReference("Requests");

        //Init
        recyclerView = (RecyclerView)findViewById(R.id.listCart);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        txtTotalPrice = (TextView)findViewById(R.id.total);
        btnPlace = (FButton)findViewById(R.id.btnPlaceOrder);

        btnPlace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Common.isConnectedToInternet(getBaseContext())) {
                    if (cart.size() > 0) {
                        showAlertDialog();
                    } else {
                        Toast.makeText(Cart.this, "Your Cart is Empty !", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(Cart.this, "Please Check your Internet Connection !", Toast.LENGTH_SHORT).show();
                }
            }
        });
        loadListFood();
    }

    private void showAlertDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Cart.this);
        alertDialog.setTitle("One more step!");
        alertDialog.setMessage("Enter your table number");

        LayoutInflater inflater = this.getLayoutInflater();
        View order_address_comment = inflater.inflate(R.layout.order_address_comment, null);

        final MaterialEditText edttableNo = (MaterialEditText)order_address_comment.findViewById(R.id.edtAddress);
        final MaterialEditText edtComment = (MaterialEditText)order_address_comment.findViewById(R.id.edtComment);

        final RadioButton rdiCard = (RadioButton)order_address_comment.findViewById(R.id.rdiCard);
        final RadioButton rdiSmartCard = (RadioButton) order_address_comment.findViewById(R.id.rdiSmartCard);

        alertDialog.setView(order_address_comment);
        alertDialog.setIcon(R.drawable.ic_shopping_cart_black_24dp);

        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(Common.isConnectedToInternet(getBaseContext())) {

                    tableno = edttableNo.getText().toString();
                    comment = edtComment.getText().toString();

                    formatAmount = txtTotalPrice.getText().toString()
                            .replace("$", "")
                            .replace(",", "");

                    //if none of the payment options is selected
                    if (!rdiCard.isChecked() && !rdiSmartCard.isChecked()) {
                        Toast.makeText(Cart.this, "Please select a payment option", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (rdiCard.isChecked()) {
                        Intent intent = new Intent(getApplicationContext(), CardDetail.class);
                        intent.putExtra("total", formatAmount);
                        startActivityForResult(intent, result);

                    } else if(rdiSmartCard.isChecked()) {
                        rfidUser = Common.currentUser.getRfidKey();
                        amount = 0;
                        try {
                            amount = Common.formatCurrency(txtTotalPrice.getText().toString(), Locale.US).doubleValue();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                        if (rfidUser.equals("not a Smart Card User")) {
                            Toast.makeText(Cart.this, "You do not have a Smart Card! Please choose another payment option.", Toast.LENGTH_SHORT).show();
                        } else if (Double.parseDouble(Common.currentUser.getBalance().toString()) >= amount) {
                            FirebaseDatabase db;
                            DatabaseReference ref;
                            db = FirebaseDatabase.getInstance();
                            ref = db.getReference("rfidKey").child(rfidUser);

                            ref.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        rfidValue = dataSnapshot.getValue().toString();
                                        loadScanState(rfidValue);
                                    }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                        else {
                            Toast.makeText(Cart.this, "Balance not enough...Order cannot not be placed !", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Cart.this, "Complete payment to place order !", Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    Toast.makeText(Cart.this, "Please Check your Internet Connection !", Toast.LENGTH_SHORT).show();
                }
            }
        });

        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        alertDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == result) {
            if(resultCode == RESULT_OK) {
                Request request = new Request(
                Common.currentUser.getPhone(),
                Common.currentUser.getName(),
                tableno,
                txtTotalPrice.getText().toString(),
                "0",
                comment,
                "Credit/Debit Card",
                "Paid",
                cart
                );

                //Submit to firebase
                String orderNumber = String.valueOf(System.currentTimeMillis());
                requests.child(orderNumber)
                   .setValue(request);

                //Delete Cart
                new Database(getBaseContext()).cleanCart();
                sendNotificationOrder(orderNumber);

                Toast.makeText(Cart.this, "Order Placed !", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private void loadScanState(final String rfidValue) {
        new CountDownTimer(30000, 1000) {
            public void onTick(long milis) {

            }
            public void onFinish() {
                if (rfidValue.equals("Scanned")) {
                    //Create new request
                    Request request = new Request(
                            Common.currentUser.getPhone(),
                            Common.currentUser.getName(),
                            tableno,
                            txtTotalPrice.getText().toString(),
                            "0",
                            comment,
                            "Smart Card",
                            "Paid through Smart Card",
                            cart
                    );

                    //Submit to firebase
                    final String orderNumber = String.valueOf(System.currentTimeMillis());
                    requests.child(orderNumber)
                            .setValue(request);

                    //Delete Cart
                    new Database(getBaseContext()).cleanCart();

                    //Update balance
                    double balance = Double.parseDouble(Common.currentUser.getBalance().toString()) - amount;
                    Map<String, Object> update_balance = new HashMap<>();
                    update_balance.put("balance", balance);
                    FirebaseDatabase.getInstance()
                            .getReference("User")
                            .child(Common.currentUser.getPhone())
                            .updateChildren(update_balance)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        FirebaseDatabase.getInstance()
                                                .getReference("User")
                                                .child(Common.currentUser.getPhone())
                                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        Common.currentUser = dataSnapshot.getValue(User.class);
                                                        FirebaseDatabase.getInstance().getReference("rfidKey").child(Common.currentUser.getRfidKey()).setValue("Unscanned");

                                                        loadListFood();
                                                        sendNotificationOrder(orderNumber);
                                                        Toast.makeText(Cart.this, "Payment Successful...Order Placed!", Toast.LENGTH_SHORT).show();
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                    }
                                }
                            });
                } else {
                    loadScanState(rfidValue);
                }
            }
        }.start();
    }

    private void sendNotificationOrder(final String orderNumber) {
        DatabaseReference tokens = FirebaseDatabase.getInstance().getReference("Tokens");
        final Query data = tokens.orderByChild("isServiceToken").equalTo(true);
        data.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot postSnapshot:dataSnapshot.getChildren()) {
                    Token serverToken = postSnapshot.getValue(Token.class);

                    Notification notification = new Notification("Smart Restaurant Notification", "You have a new Order !"+orderNumber);
                    Sender content = new Sender(serverToken.getToken(), notification);

                    mService.sendNotification(content)
                            .enqueue(new Callback<MyResponse>() {
                                @Override
                                public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                                    if(response.code() == 200) {
                                        if (response.body().success == 1) {
                                            Toast.makeText(Cart.this, "Order Placed !", Toast.LENGTH_SHORT).show();
                                            finish();
                                        } else {
                                            Toast.makeText(Cart.this, "Failed to place Order...Try Again", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Call<MyResponse> call, Throwable t) {
                                    Log.e("Error", t.getMessage());

                                }
                            });

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void loadListFood() {
        cart = new Database(this).getCarts();
        adapter = new CartAdapter(cart, this);
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);

        //total price
        int total=0;
        for(Order order:cart)
            total+=(Integer.parseInt(order.getPrice()))*(Integer.parseInt(order.getQuantity()));

        Locale locale = new Locale("en", "US");
        NumberFormat fmt = NumberFormat.getCurrencyInstance(locale);

        txtTotalPrice.setText(fmt.format(total));
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if(item.getTitle().equals(Common.DELETE)) {
            deleteCart(item.getOrder());
        }
        return true;
    }

    private void deleteCart(int position) {
        //remove item in list by position
        cart.remove(position);
        //delete list from SQLite
        new Database(this).cleanCart();
        //update new data from list to SQLite
        for(Order item:cart) {
            new Database(this).addToCart(item);
        }
        //Refresh to see changes
        loadListFood();
    }
}
