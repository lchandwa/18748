package edmt.dev.srserver.Remote;

import edmt.dev.srserver.Model.MyResponse;
import edmt.dev.srserver.Model.Sender;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface APIService {
    @Headers(
            {
                    "Content-Type:application/json",
                    "Authorization:key=AAAAA8fovu0:APA91bEl3vmY_bHH8wbB6v3eIVIk2sZ4r8gVaMTgzpuukDs2r2xW56RKv-vroNW_085_oPZwTvYCdDEvl3g1U7MJvU6LCxjOWFjNRkcsCRpTP9JZGVBH0ycE57kUgU78-visucLXrUK6"
            }
    )
    @POST("fcm/send")
    Call<MyResponse> sendNotification(@Body Sender body);
}
