package edmt.dev.srserver.Model;

public class Result {
    public String message_id;
}
