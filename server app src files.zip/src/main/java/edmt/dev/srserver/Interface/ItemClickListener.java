package edmt.dev.srserver.Interface;

import android.view.View;

public interface ItemClickListener {
    void onClick(View v, int position, boolean isLongClick);
}
