package edmt.dev.srserver.Common;

import edmt.dev.srserver.Model.Request;
import edmt.dev.srserver.Model.User;
import edmt.dev.srserver.Remote.APIService;
import edmt.dev.srserver.Remote.RetrofitClient;

public class Common {
    public static User currentUser;
    public static Request currentRequest;
    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";
    public static final int PICK_IMAGE_REQUEST = 71;

    public static final String fcmUrl = "https://fcm.googleapis.com/";

    public static String convertCodeToStatus(String code) {
        if(code.equals("0")) {
            return "Order Placed";
        } else if(code.equals("1")) {
            return "Order received...Preparing";
        } else {
            return "Order ready and on your way";
        }
    }

    public static APIService getFCMClient() {
        return RetrofitClient.getClient(fcmUrl).create(APIService.class);
    }
}
